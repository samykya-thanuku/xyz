package com.cg.payroll.main;
//import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	//@SuppressWarnings("resource")
	public static void main(String[] args) {
		PayrollServices payrollServices = new PayrollServicesImpl();
/*		Scanner sc = new Scanner(System.in);
		int newId = 0;
		float z;
		for(int a=1;a<=5;a++) {
			System.out.println("Enter the choice \n1.Insert\n2.Update\n3.calculate salary\n4.delete\n5.get details");
			int x=sc.nextInt();
			switch(x) {
			case 1: newId= payrollServices.acceptAssociateDetails(sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.next(),sc.next() );
					System.out.println("Associate ID = "+newId);
					break;
			case 2: break;
			case 3: newId=sc.nextInt();
					z=payrollServices.calculateNetSalary(newId);
					System.out.println("slary for id = "+z);
					break;
			case 4: int deletionId=sc.nextInt();
					Associate a1=payrollServices.getAssociateDetails(deletionId);
					System.out.println(payrollServices.delete(a1));
					break;
			case 5: int Id=sc.nextInt();
					Associate a2=payrollServices.getAssociateDetails(Id);
					System.out.println(a2.toString());
					break;
			   //case : a=6;
					//break;
			default : a=6;
						System.out.println("ALL DONE");
			}
		}*/
		int newId=payrollServices.acceptAssociateDetails("daya", "samala", "jhsdhjyh", "sfgd", "dv", "djhg", 150000,30000,1000,1000, 212, "bankName", "ifscCode") ;
		System.out.println(newId);
		float y = payrollServices.calculateNetSalary(newId);
		System.out.println(y);
		Associate a1=payrollServices.getAssociateDetails(newId);
		System.out.println("Monthly tax= " +a1.getSalary().getMonthlyTax());
		System.out.println(a1.toString());
	}
}
