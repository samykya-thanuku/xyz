package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;

public interface PayrollServices {

	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, float yearlyInvestmentUnder80C, float basicSalary, float epf, float companyPf,
			float accountNumber, String bankName, String ifscCode);

	float calculateNetSalary(int associateId);

	Associate getAssociateDetails(int associateId);

	Associate[] getAssociateDetails();

	boolean acceptAssociateDetailsForUpdate(int associateId, String firstName, String lastName, String emailId,
			String department, String designation, String pancard, float yearlyInvestmentUnder80C, float basicSalary,
			float epf, float companyPf, float accountNumber, String bankName, String ifscCode);

	//		public boolean delete(Associate associate) {
	//		return daoservices.deleteAssociate(associate);
	//}
	boolean delete(Associate associate);

}